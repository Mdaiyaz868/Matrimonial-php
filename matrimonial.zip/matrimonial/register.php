<?php
include_once('db_conn.php');

$name = $_POST['email'];
$password = $_POST['password'];
$cpassword = $_POST['cpassword'];

// You should use prepared statements to prevent SQL injection
$sql = "INSERT INTO login (email, password, cpassword) VALUES (?, ?, ?)";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "sss", $name, $password, $cpassword);
if (mysqli_stmt_execute($stmt)) {
    // Registration successful, redirect to the home page
    mysqli_stmt_close($stmt);
    mysqli_close($conn);
    header("Location: login_sign.html");
    exit;
} else {
    echo "Error: " . mysqli_error($conn);
    mysqli_stmt_close($stmt);
    mysqli_close($conn);
}
?>

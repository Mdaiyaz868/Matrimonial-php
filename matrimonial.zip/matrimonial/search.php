<?php
include_once('db_conn.php');
$name = $_POST['name'];
$gender = $_POST['gender'];
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM about";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    echo '<html>
            <head>
                <style>
                    table {
                        font-family: Arial, sans-serif;
                        border-collapse: collapse;
                        width: 100%;
                    }

                    table, th, td {
                        border: 1px solid black;
                    }

                    th, td {
                        text-align: left;
                        padding: 8px;
                    }
                </style>
            </head>';

    echo '<table>';
    echo '<tr>
            <th><b>Name</b></th>
            <th><b>Email</b></th>
            <th><b>Gender</b></th>
            <th><b>Contact</b></th>
            <th><b>Image</b></th>
            <th><b>Search new</b></th>
        </tr>';
    
    while ($row = $result->fetch_assoc()) {
        if ($row['name'] == $name && $row['gender'] == $gender) {
            echo '<tr>';
            echo '<td>' . $row['name'] . '</td>';
            echo '<td>' . $row['email'] . '</td>';
            echo '<td>' . $row['gender'] . '</td>';
            echo '<td>' . $row['contact'] . '</td>';
            echo '<td><img height="100" src="' . $row['files'] . '"></td>';
            echo '<td><a href="search.html">Search other</a></td>';
            echo '</tr>';
        }
    }
    echo '</table>';
}
$conn->close();
?>

<?php
include_once('db_conn.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = $_POST['fullName'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];
    $contact = $_POST['contact'];
    $message = $_POST['message'];

    $insert_sql = "INSERT INTO contact (fullname, email, gender, contact, message) VALUES ('$fullname', '$email', '$gender', '$contact', '$message')";

    if (mysqli_query($conn, $insert_sql)) {
        echo "<script type='text/javascript'>alert('Successful - Record Updated!');</script>";
        
        // Retrieve recipients from the 'about' table
        $select_sql = "SELECT name, email FROM about";
        $result = mysqli_query($conn, $select_sql);

        if ($result) {
            while ($row = mysqli_fetch_array($result)) {
                $recipientEmail = $row['email'];
                $recipientName = $row['name'];
                if ($recipientEmail === $email) {
                    echo "Message received by: $recipientName";
                }
            }
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        echo "Error: " . mysqli_error($conn);
    }
} else {
    echo "Invalid request method.";
}
?>

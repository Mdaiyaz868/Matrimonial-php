<?php
    $conn = new mysqli("localhost","root","","matrimony");
?>
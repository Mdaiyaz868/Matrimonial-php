-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 06, 2023 at 08:12 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `matrimony`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE `about` (
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `contact` varchar(30) NOT NULL,
  `message` varchar(100) NOT NULL,
  `files` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`name`, `email`, `gender`, `contact`, `message`, `files`) VALUES
('Aiyaz', 'aiyaz@gmail.com', 'Male', '1234567890', 'My name is Aiyaz', '????0eExif\0\0II*\0\0\0\0\0\0\0\0\0\0'),
('Aaquib', 'Aaquib@gmail.com', 'Male', '9876543210', 'My name is Aaquib', '????\0JFIF\0\0\0\0\0\0??\0?\0\n');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `fullname` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `contact` varchar(30) NOT NULL,
  `message` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `cpassword` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`email`, `password`, `cpassword`) VALUES
('mdaiyaz09@gmail.com', 'Aiyaz123', 'Aiyaz123'),
('mdaiyaz308@gmail.com', 'Aiyaz123', 'Aiyaz123'),
('mdaiyaz308@gmail.com', 'Aiyaz123', 'Aiyaz123'),
('ritik2023@gmail.com', '12345', '12345'),
('ritik2023@gmail.com', '12345', '12345'),
('abc123@gmail.com', '12345', '12345'),
('diwakargiri234@gmail.com', '12345', '12345'),
('diwakargiri234@gmail.com', '12345', '12345'),
('diwakargiri@gmail.com', '12345', '12345'),
('diwakarg@gmail.com', '12345', '12345');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

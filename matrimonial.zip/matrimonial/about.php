<?php
    error_reporting(E_ALL);
    ini_set('display_errors', 'On');
    
    $name = $_POST['name'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];
    $contact = $_POST['contact'];
    $message = $_POST['message'];
    $file_name = $_FILES['image']['name'];
    $file_tmp = $_FILES['image']['tmp_name'];
    $upload_path = "uploads/" . $file_name;

    // Check if the file was successfully uploaded
    if (move_uploaded_file($file_tmp, $upload_path)) {
        // File was uploaded successfully

        // Establish a database connection (Update your database credentials)
        // $conn = new mysqli("localhost", "root", "", "matrimony");
        include 'db_conn.php';

        // Check for a successful database connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Escape and sanitize the image data
        $imageData = $conn->real_escape_string(file_get_contents($upload_path));

        // Prepare and execute the SQL query
        $sql = "INSERT INTO about (name, email, gender, contact, message, files) VALUES ('$name', '$email', '$gender', '$contact', '$message', '$imageData')";
        if (mysqli_query($conn, $sql)) {
            // Successful popup message, redirect to home.html
            echo "<script type='text/javascript'>alert('Successful - Record Updated!'); window.location.href = 'home.html';</script>";
        } else {
            // Unsuccessful popup message, redirected back to home.html
            echo "<script type='text/javascript'>alert('Unsuccessful - ERROR!'); window.location.href = 'home.html';</script>";
        }

        // Close the database connection
        $conn->close();
    } else {
        // Error in file upload
        echo "<script type='text/javascript'>alert('Error - File Upload Failed!'); window.location.href = 'home.html';</script>";
    }
?>





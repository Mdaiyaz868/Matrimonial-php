<?php
include_once('db_conn.php');

$emaill = $_POST['email'];
$passwordd = $_POST['password'];

// Use prepared statements to prevent SQL injection
$sql = "SELECT email, password FROM login WHERE email = ? AND password = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ss", $emaill, $passwordd);
mysqli_stmt_execute($stmt);
mysqli_stmt_store_result($stmt);

if (mysqli_stmt_num_rows($stmt) > 0) {
    // Login success, redirect to the home page
    mysqli_stmt_close($stmt);
    mysqli_close($conn);
    echo "<script>alert('Login SucessFully!')</script>";
    header("Location: home.html");
    exit;
} else {
    // Login failed, show alert and redirect to login page
    mysqli_stmt_close($stmt);
    mysqli_close($conn);
    echo "<script type='text/javascript'>alert('Please Sign Up First'); window.location.href = 'login_sign.html';</script>";
}
?>
